const car = {
    make: 'Honda',
    model: 'Accord',
    year: 2020
  };
  
  const keys = Object.keys(car);
  
  console.log(keys);
  